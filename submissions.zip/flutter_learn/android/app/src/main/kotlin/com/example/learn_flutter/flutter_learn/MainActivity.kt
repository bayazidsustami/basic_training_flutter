package com.example.learn_flutter.flutter_learn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
